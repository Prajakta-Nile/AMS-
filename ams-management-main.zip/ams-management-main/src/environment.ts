export const environment = {
    production: false,
    apiUrl: 'http://localhost:8761' // Update with your actual API URL
  };
  