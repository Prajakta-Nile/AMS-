declare module 'crypto-js';
