package com.ams.Exceptions;

public class FlightAlreadyPresentExceptions extends RuntimeException {
	public FlightAlreadyPresentExceptions(String s) {
		super(s);
	}
}