package com.ams.Exceptions;

public class CarrierNotFoundException extends Exception {

    public CarrierNotFoundException(String message) {
        super(message);
    }
}
