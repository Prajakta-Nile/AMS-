package com.ams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
